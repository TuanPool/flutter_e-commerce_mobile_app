class ProductImage {
  static const String iphone11promax = "assetsimagesproductscellphoneicon.jpg";
}
