class KSpace{
  KSpace._();

  static const double horizontalSpace = 20;
  static const double horizontalSmallSpace = 8;
}