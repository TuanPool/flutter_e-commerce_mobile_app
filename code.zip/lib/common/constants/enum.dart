enum OrderStatus{processing, shipped, delivered}

enum PaymentMethod{eWallet , bankTransfer, creditCard, cashOnDelivery}