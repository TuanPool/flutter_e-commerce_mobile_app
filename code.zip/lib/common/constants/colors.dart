import 'package:flutter/material.dart';

class KColors{
  KColors._();

  static const Color primaryColor = Color(0xFF4B68FF);
  static const Color lightModeColor = Color.fromARGB(186, 0, 0, 0);
  static const Color dartModeColor = Color.fromARGB(191, 255, 255, 255);
}